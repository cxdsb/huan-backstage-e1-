module.exports = {
    model: {
        title:"",
        begintime:"",
        endtime:"",
        first_cateid:"",
        second_cateid:"",
        goodsid:"",
        status:""
    },
    check: dataArr => dataArr // 不处理, 只为了不报错
}